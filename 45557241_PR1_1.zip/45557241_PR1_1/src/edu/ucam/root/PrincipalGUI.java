package edu.ucam.root;

import edu.ucam.crud.TallerSingleton;
import edu.ucam.gui.windows.VentanaLogin;

public class PrincipalGUI {

	public static void main(String[] args) {
		
		VentanaLogin v1 = new VentanaLogin();
		v1.setVisible(true);
	}
}
